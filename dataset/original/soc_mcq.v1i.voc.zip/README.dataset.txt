# soc_mcq > 2022-12-05 6:16pm
https://universe.roboflow.com/test-m7eij/soc_mcq

Provided by a Roboflow user
License: CC BY 4.0

